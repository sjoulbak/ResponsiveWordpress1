<DIV id="footer">
	<?php wp_footer(); ?>
  </DIV>
</DIV>
</body>
</html>