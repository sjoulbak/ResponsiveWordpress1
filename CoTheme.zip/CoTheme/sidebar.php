	<DIV id="sidebar">
	  <?php if ( ! dynamic_sidebar( 'sidebar' ) ) : ?>
	    <!-- HTML voor als de sidebar leeg is -->
	  <?php endif; ?>
	</DIV>